# Aplicativo para Ensino de Crianças

## Sobre o projeto

Projeto desenvolvido no Trabalho de Conclusão de Curso de Engenharia de Software.

## **Objetivos do Projeto:**

* Elaborar o protótipo de um aplicativo voltado para o ensino de crianças.

* Elaborar a documentação do projeto.

## Sobre o Portótipo

* Ferramenta utilizada para a prototipação de telas: Figma Online.

* Link para uso inicial do protótipo: https://www.figma.com/file/TZR3CZQWU1AnDespexqltq/APEDC?node-id=0%3A1

**Obs: Todas as imagens utilizadas no projeto possuem licença de uso Creative Commons.**